//Seeing if the list is sorted already or not
//Hw #5, exercise 4
//Make a for loop and iterate through all values seeing if they are from smallest to largest

import java.util.Scanner;

public class Sorter_ex4{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter how many values you want to enter");

		int listlength = input.nextInt();

		int [] myArray = new int [listlength];

		System.out.println("Please enter values");
		for (int i = 0; i <= myArray.length -1; i++){
			myArray[i] = input.nextInt();
		}

		//Call my method here
		//Then we do some magic
		//If it did return true, then we can say it is sorted
		if(isSorted(myArray)){
			System.out.println("The list is already sorted");
		}
		else {
			System.out.println("The list is not sorted");
		}
		//Always gotta make sure I close that Scanner
		input.close();
	}

	//looking for a false case within the method
	public static boolean isSorted(int [] newArray){
		int initialVal = newArray[0];

		for(int j = 0; j <= newArray.length-1; j++)
			if (newArray[j] < initialVal){
				//The moment this is false, whole loop will break
				return false;

			}
			//if the whole loop remains true, we will return true
			return true;


		}
				

}