//Reverse a number
//Given our constraints, we can use remainders

import java.util.Scanner;

public class IntegerReversal_ex8{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter your desired number");
		int number = input.nextInt();
		
		//Calling my method

		System.out.println("The reversed number is: " + Reversal(number));

	}

	public static int Reversal(int x){
		// Using a base case
		// I'm using reverse to add the remainders then multiply by 10

		int reverse = 0;
		while(x != 0){
			//we multiply our current value by 10 each time
			reverse *= 10;
			reverse += x % 10;
			//Overall value divided by 10
			x /= 10;
			}
		// Returning my reversed value
		return reverse;
		}
	}
