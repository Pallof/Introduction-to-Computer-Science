
import java.util.Date;
import java.text.SimpleDateFormat;

public class Account_ex5 {
	
	private int id = 0;
	private double Balance = 0;
	//all accounts have the same interest rate
	private double InterestRate = 0;
	private Date DateCreated;
	
	
	public Account_ex5() {
	}
	
	public Account_ex5(int newid, double newBalance) {
		this.id = newid;
		this.Balance = newBalance;
	}
	
	public double withraw(double amount) {
		Balance -= amount;
		return Balance;
		
	}
	
	public double deposit(double amount) {
		Balance += amount;
		return Balance;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getBalance() {
		return Balance;
	}

	public void setBalance(double balance) {
		Balance = balance;
	}

	public double getInterestRate() {
		return InterestRate;
	}

	public void setInterestRate(double interestRate) {
		InterestRate = interestRate;
	}

	public Date getDateCreated() {
		//don't know why i made this, but i guess i didnt need it
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date CurrentDate = new Date();
		
		return CurrentDate;
	}

	public void setDateCreated(Date dateCreated) {
		DateCreated = dateCreated;
	}
	
	// Interest Rate monthly is just regular IR/12;
	public double getMonthlyInterest() {
		return InterestRate/12;
	}
	public void DisplayInfo() {
		System.out.println("Your id is: " + id);
		System.out.println("Your Current Balance is " + Balance);
		System.out.println("Your monthly interest rate is " + this.InterestRate/12);
		System.out.println("Your account was created on " + this.getDateCreated());
	}
	
}
