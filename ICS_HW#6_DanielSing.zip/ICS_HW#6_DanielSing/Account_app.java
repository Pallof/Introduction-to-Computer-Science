
import java.util.Scanner;

public class Account_app {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Account_ex5 X1 = new Account_ex5();
		
		X1.setId(1122);
		X1.setBalance(20000);
		X1.setInterestRate(4.5);
		X1.withraw(2500);
		X1.deposit(3000);
		//Everything is set above, below will display all of my info
		X1.DisplayInfo();
	}
}
