// Create an ATM machine, this time using methods
// we will have 3 methods, 1 to deposit, 1 to withdraw, and 1 to show balance.


import java.util.Scanner;

public class ATMachine_ex1{

	public static double balance = 0;

	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		int option;
		do{
		menu();
		System.out.println("Please enter an option");
		option = input.nextInt();
			// using a switch, more efficient than if/else statements
			switch (option){
				case 1:
					balance();
					break;
				case 2: 
					System.out.println("Please enter how much you would like to deposit");
					double x = input.nextDouble();
					deposit(x);
					break;
				case 3:
					System.out.println("Please enter how much you would like to withdraw");
					double y = input.nextDouble();
					withdrawal(y);
					break;
				case 4: 
					System.out.println("Goodbye, see you again!");
					break;
				default:
					System.out.println("No such option exists");
					break;
			}
		}
		while (option != 4);
		// make sure to close your scanners
		input.close();

	}
	// One of my two methods that have no inputs, just displays the menu over and over again for
	// for customer ease
	public static void menu(){
		System.out.println("1. View your account balance");
		System.out.println("2. Deposit Cash");
		System.out.println("3. Withdraw Cash");
		System.out.println("4. Exit ATM");
		}
	// Second void method to show balance
	public static void balance(){
		System.out.println("Your current balance is " + balance);
		}

		// method for how much to deposit each time
	public static double deposit(double amount){
		//System.out.println("Please enter how much you would like to deposit");
		balance += amount;
		return balance;
		}
		// method with input for how much to withdraw, if inputted amount is greater
		// than balance then we wont allow an overdraw

	public static double withdrawal(double amount){
		//System.out.println("Please enter how much you would like to withdraw");
		if (amount > balance){
			System.out.println("You have insufficient funds");
			}

		else {
			balance -= amount;
			}

		return balance;

	}
	
}


