// Password checker
// Default password is 'NYU1256'

import java.util.Scanner;

public class Password_ex5 {
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	String s1 = "NYU1256";

	System.out.println("Please enter your password");
	String s2 = input.next();

	if (s2.equals(s1))
	System.out.println("The password is correct");
	else
	System.out.println("Incorrect Password");


	input.close();
	}
}