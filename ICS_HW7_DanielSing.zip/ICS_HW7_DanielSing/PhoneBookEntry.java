//These are ENTRY'S, MEANING EACH CONTACT YOU PUT INTO THE CONTACT LIST, THE USER AND ADMIN ARE PHYSICAL USERS WHICH USE THIS OBJECT
public class PhoneBookEntry {
	//making everything protected so that it can be extendible
	protected int ID;
	protected String FirstName;
	protected String LastName;
	protected String Email;
	protected String ZipCode;
	protected String PhoneNumber;
	protected String Username;
	protected String Password;
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	public PhoneBookEntry() {
		
	}
	public PhoneBookEntry(int id, String Fn, String Ln, String email, String Zip, String Number) {
		this.ID = id;
		this.FirstName = Fn;
		this.LastName = Ln;
		this.Email = email;
		this.ZipCode = Zip;
		this.PhoneNumber = Number;
	}
	public void PrintEntryInfo() {
		System.out.println(ID);
		System.out.println(FirstName);
		System.out.println(LastName);
		System.out.println(Email);
		System.out.println(ZipCode);
		System.out.println(PhoneNumber);
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getZipCode() {
		return ZipCode;
	}
	public void setZipCode(String zipCode) {
		ZipCode = zipCode;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	
	
}


