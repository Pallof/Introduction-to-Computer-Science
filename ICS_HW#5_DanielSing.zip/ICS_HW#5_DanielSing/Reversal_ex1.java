// ICS Homework #5, Problem 1, reversing a number
//Last time we did this using remainders but since we can now use a loop
//just use a for loop and reverse loop through it


import java.util.Scanner;

public class Reversal_ex1{
	public static void main(String[] args){


		int [] inserted_array = new int[10];
		//we need to fill in the numbers
		filler(inserted_array);
		
		System.out.println("Here are the numbers you input Reversed");
		//Reversing it using a for loop
		for(int i = inserted_array.length -1; i >=0; i--){
			//not using ln because it looks better like this
			System.out.print(inserted_array[i] + "  ");
			}
		//Call method here
	}

	public static int[] filler(int [] n){
		//Creating a scanner in my method, because i couldnt use it outside my method
		Scanner input = new Scanner(System.in);
		for(int j = 0; j < n.length; j++){
			//filling each indice of i
			System.out.println("Please enter a number");
			n[j] = input.nextInt();
		}

		input.close();
		return n;

	}
}