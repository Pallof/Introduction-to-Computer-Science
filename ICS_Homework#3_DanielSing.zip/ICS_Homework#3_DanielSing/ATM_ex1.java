// Hw # 3  Exercise 1
// Create an atm

import java.util.Scanner;
public class ATM_ex1{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		// set up all my variables
		int option;
		double withdraw;
		double deposit;
		double balance = 0;
		//Create a do while loop so that Ill go through one cycle at least once
		do {
			// creating all them print statements like a boss
			System.out.println("1. View your account Balance");
			System.out.println("2. Deposit Cash");
			System.out.println("3. Withdraw Cash");
			System.out.println("4 Exit 	\n");
			System.out.println("Please enter your selection 	\n");
			option = input.nextInt();

			// set up my boolean values
			
			if (option == 1){
				System.out.println("Your current balance is " + balance);
			}

			else if (option == 2) {
				System.out.println("How much would you like to deposit ");
				deposit = input.nextDouble();
				if (deposit <= 0){
					System.out.println("You cannot deposite negative cash or zero cash ");
					continue;
					}
				else {
					balance += deposit;
					System.out.println("You have deposited $" + deposit + " dollars");
				}
			}


			else if(option == 3) {
				System.out.println("How much cash would you like to withdraw?");
				withdraw = input.nextDouble();
				if (withdraw > balance){
					System.out.println("You cannot withdraw more than your current balance");
					continue;
					}
				else {
					balance -= withdraw;
					System.out.println("You have withdrawn $" + withdraw + "Dollars");
				}
			}

			}while(option != 4);
				System.out.println("Goodbye!");

		input.close();
		
	}
}