// Converting Decimal Numbers to binary

import java.util.Scanner;

public class Conversion_ex5{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter you number you would like to convert");
		int decimal = input.nextInt();

		// Using the method given in hw to convert to Binary
		//Thought Decimal meant float or Double
		System.out.println("Your number in binary format is " + Integer.toBinaryString(decimal));

	}
}