import java.util.Scanner;

//PHONEBKENTRY 2 IS JUST MY STANDARD USER, creates an IS-A relationship
public class User extends PhoneBookEntry implements User_IF{
	//Empty User Class, everytime a new user is created
	//Overloading the constructor with different inputs
	//Each 

	public User() {
		
	}
	//USER HAS AN ID, USERNAME AND PASSWORD, DIFFERENT FROM ADMIN LOGIN CREDENTIALS
	public User(int id, String user, String Pass) {
		this.ID = id;
		this.Username = user;
		this.Password = Pass;
//Not sure if I need this part
//		User.super.setUsername("U");
//		User.super.setPassword("P");
	}
	
	PhoneBookEntry [] trackinglist = new PhoneBookEntry[6];
	//this top variable is the top of my array or the new contact to be entered
	public int top = 0;
	
	public void User_menu() {
		System.out.println("1. Add a PhoneBookEntry");
		System.out.println("2. Edit a PhoneBookEntry");
		System.out.println("3. Sort the phonebook Entry by ID (Binary)");
		System.out.println("4. Search for an entry by PhoneNumber");
		System.out.println("5. Display User info");
	}
	public void Add() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter ID");
		trackinglist[top].setID(input.nextInt());
		System.out.println("Please enter First name");
		trackinglist[top].setFirstName(input.next());
		System.out.println("Please enter last name");
		trackinglist[top].setLastName(input.next());
		System.out.println("Please enter email Address");
		trackinglist[top].setEmail(input.next());
		System.out.println("Please enter Zipcode");
		trackinglist[top].setZipCode(input.next());
		System.out.println("Please enter phone number");
		trackinglist[top].setPhoneNumber(input.next());
		top++;
		
		input.close();
		// TODO Auto-generated method stub
		
	}

	public void Edit(PhoneBookEntry d) {
		Scanner input = new Scanner(System.in);
		int Edit_option;
		for(int k = 0; k < trackinglist.length; k++) {
			if(trackinglist[k].getFirstName().equals(d.getFirstName()) || trackinglist[k].getLastName().equals(d.getLastName())) {
				System.out.println("What would you like to edit");
				System.out.println("1.Id, \n  2.First Name, \n 3. Last Name,\n 4. Email,\n 5. Zipcode,\n 6.PhoneNumber");
				Edit_option = input.nextInt();
				switch(Edit_option) {
				case 1:
					System.out.println("Enter a new ID");
					trackinglist[k].setID(input.nextInt());
					break;
				case 2: 
					System.out.println("Enter a new first name");
					trackinglist[k].setFirstName(input.next());
					break;
				case 3:
					System.out.println("Enter a new Last Name");
					trackinglist[k].setLastName(input.next());
					break;
				case 4:
					System.out.println("Enter a new email");
					trackinglist[k].setEmail(input.next());
					break;
				case 5:
					System.out.println("Enter a new Zipcode");
					trackinglist[k].setZipCode(input.next());
					break;
				case 6:
					System.out.println("Enter a new PhoneNumber");
					trackinglist[k].setPhoneNumber(input.next());
					break;
				default:
					break;
					
				}
				
			}
		}
		input.close();
		
		
		// TODO Auto-generated method stub
		
	}
	//We are sorting by ID number from smallest to largest, there is no specific style
	//Im not completely sure this is a viable method
	//Originally i was calling from phonebookapp, however that was working with my mainframe
	//So I changed it to type phonebookentry[] trackiinglsit2
	public void Sorter(PhoneBookEntry[] trackinglist2) {
		//check with tutor if this bubble sort is right;
		PhoneBookEntry [] temp_arr = trackinglist2;
		for(int i =0 ; i < temp_arr.length; i++) {
			//Double check this because not sure if it works or not
			PhoneBookEntry temp = temp_arr[i+1];
			if(temp_arr[i].getID() > temp_arr[i+1].getID()) {
				temp_arr[i+1] = temp_arr[i];
				temp_arr[i] = (User) temp;
			}
		}
		
		// TODO Auto-generated method stub

	}

	public void SearchByNumber(String num) {
		for(int j= 0; j< trackinglist.length; j++) {
			if(num.equals(trackinglist[j].getPhoneNumber())){
				trackinglist[j].PrintEntryInfo();
			}
		}
		
		
	}


	//this is wrong, you need to print the specific contact from the entrybook.
	public void Display() {
		System.out.print(ID);
		System.out.println(Username);
		System.out.println(Password);
		}
	@Override
	public void Sorter(PhoneBookApp p) {
		// TODO Auto-generated method stub
		
	}
	
	
}

	

