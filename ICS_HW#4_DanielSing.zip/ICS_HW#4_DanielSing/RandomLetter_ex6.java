//Generate a random letter
// In order to do this we will use both the random method and ASCII table

public class RandomLetter_ex6{
	public static void main(String[] args){

		System.out.println("Your random letter is");
		//Calling my method
		Generator();
	}
	public static void Generator(){
		//Multiply by 26, because thats how many letters in the alphabet
		//Generating random numbers then adding at where the first ASCII starts
		double randomNumber = (int)((Math.random()*26) + 65);
		System.out.println((char)randomNumber + " ");
		//Im not sure if you guys wanted lower case letter
		//Code below is for lower case letters
		//double randomNumber2 = (int)(Math.random()*26 + 97);
	}
}