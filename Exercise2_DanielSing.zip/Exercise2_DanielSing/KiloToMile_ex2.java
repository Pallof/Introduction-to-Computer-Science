// Kilometers to miles
import java.util.Scanner;
public class KiloToMile_ex2
 {
	public static void main(String[] args)
	{

		Scanner input = new Scanner(System.in);
		
		final double MILES_PER_KILO = 0.6214;
		double kilometers;
		System.out.println("Please enter an amount of Kilometers");
		kilometers = input.nextDouble();

		double conversion;

		conversion = kilometers / MILES_PER_KILO;

		System.out.println("From Kilometers to Miles:  " + kilometers + " Kilometers is equivalent to " + conversion + " Miles");

		input.close();
	}
}