//Overloading methods that return the avg of an array
// Need two methods with specific signatures
//Each method takes different inputs but has the same name, java can seperate which is which

import java.util.Scanner;

public class Overload_ex3{
	public static void main(String[] args){


	Scanner input = new Scanner(System.in);
	double [] myArray = new double [10];
	//For loop to fill in all my indexes
	System.out.println("Please enter 10 values for me to average");
	for(int i = 0; i <= myArray.length -1; i++){

		myArray[i] = input.nextDouble();

		}
	//call method
	System.out.println("Your average value from the given values are: " + average(myArray));


	input.close();
	}


	//This method takes all double arrays
	public static double average(double [] mylist){
		double sum = 0;
		for(int j=0; j <= mylist.length-1; j++){
			sum += mylist[j];
		}
		//returning my values
		return sum /= 10;
	}

	//Take method takes all int arrays
	public static int average(int [] mylist){
		int sum = 0;
		for(int k = 0; k <= mylist.length -1 ; k++){
			sum += mylist[k];
		}
		//returning my values
		return sum /= 10;
	}



}