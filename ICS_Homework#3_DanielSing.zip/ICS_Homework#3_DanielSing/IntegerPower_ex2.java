//Power of an integer
// Using a for loop

import java.util.Scanner;

public class IntegerPower_ex2{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);	

	System.out.print("Enter an Integer: ");
	int integer = input.nextInt();
	System.out.print("What power do you want " + integer + " to be raised to?: ");

	int power = input.nextInt();
//Set my initial number ansnwer to the desired integer
// Set a counter and used an boolean statement to format everything
	int answer = integer;
	int i;
	for (i = 1; i <= power; i++){

		if (i<power){
			System.out.print(integer + " x ");
			answer *= integer;
	// Keep multiplying by the same number to get "Power"
		}
		else if (i == power){
			System.out.print(integer);
		}

	}
	// \n to format it better within the script console
	System.out.print(" = " + answer + "\n"); 

	input.close();
	}
}