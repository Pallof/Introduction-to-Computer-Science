// Exercise 9, declaring variables

public class Declaration_ex9 {
	public static void main(String[] args) {

	final int X1 = 20;
	final int X2 = 3;

	final double D1 = 14.6;
	final String S1 = "Hello 101";

	// Assuming that values are just what the string themselves are
	System.out.println("Value of X1 is: " + X1);
	System.out.println("Value of X2 is: " + X2);
	System.out.println("Value of D1 is: " + D1);
	System.out.println("Value of your string is: " + S1);



	}
}