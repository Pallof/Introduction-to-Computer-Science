//Write a method that prints out a random number given a specific range from a to b
//Same principle as printing out a random character, we just dont need to use ASCII table

import java.util.Scanner;

public class RandomRange_ex7{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	//Collecting my inputs
	System.out.println("Please enter the first number of your range");
	int rangeA = input.nextInt();

	System.out.println("Please enter the second number of your range");
	int rangeB = input.nextInt();

	//Calling my method with my two inputs
	System.out.println("Your random number in that given range is " + RandomNumber(rangeA, rangeB));

	}

	public static int RandomNumber(int x , int y){
		int generator;
		if (x > y){
			//To figure out how many numbers we need we take the difference
			int dif = x - y;
			//Same principle as last problem but we always add y at the end, because that is our base case
			//
			generator = (int)((Math.random()*dif) + y);
		}
		// Just in case they put in a large value for y
		else{
			int dif = y - x;
			generator = (int)((Math.random()*dif) + x);
		}

		//returning my value
		return generator;
	}
}