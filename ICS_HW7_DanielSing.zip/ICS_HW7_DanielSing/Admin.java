import java.util.Scanner;

//PHONEBKENTRY 2 IS JUST MY STANDARD USER, creates an IS-A relationship
public class Admin extends PhoneBookEntry implements Admin_IF {

		public PhoneBookEntry [] trackinglist = new PhoneBookEntry[6];
		//this top variable is the top of my array or the new contact to be entered
		public int top = 0;
		public Admin() {

		}
		
		//Each contact created within the Admin object
		
		//ADMIN HAS USERNAME, PASSWORD AND AN EMAIL DIFFERENT CREDENTIALS THAN USER;
		public Admin(String Username, String Password, String email) {
			this.Username = Username;
			this.Password = Password;
			this.Email = email;

			//I'm currently setting this up as the temporary for username and password when i need to change it later in the admin function
		//Not sure If ill need this
//			Admin.super.setUsername("U");
//			Admin.super.setPassword("P");
			
		}
//		Add a phone entry
//		▪ Edit a phone entry of a given first name and last name
//		▪ Delete a phone entry of a given first name and last name
//		▪ Sort the PhoneBookDirectory
//		▪ Search using Linear Search
//		▪ Search using Binary Search
//		▪ Print Admin’s info
//		▪ Change Password
//		▪ Change Username
		public void Admin_menu() {
			System.out.println("1. Add a PhoneBookEntry");
			System.out.println("2. Edit a PhoneBookEntry, Enter first and last name");
			System.out.println("3. Delete a PhoneBookEntry by firstname and last name");
			System.out.println("4. Sort the PhoneBook by ID(binary)");
			System.out.println("5. Search for an entry by PhoneNumber (Linear Search)");
			System.out.println("6. Search for an entry by ID (Binary Seach)");
			System.out.println("7. Print the Admin's Info");
			System.out.println("8. Change your Password");
			System.out.println("9. Change you username");
		}
		
		public void Add() {
			Scanner input = new Scanner(System.in);
			System.out.println("Enter ID");
			trackinglist[top].setID(input.nextInt());
			System.out.println("Please enter First name");
			trackinglist[top].setFirstName(input.next());
			System.out.println("Please enter last name");
			trackinglist[top].setLastName(input.next());
			System.out.println("Please enter email Address");
			trackinglist[top].setEmail(input.next());
			System.out.println("Please enter Zipcode");
			trackinglist[top].setZipCode(input.next());
			System.out.println("Please enter phone number");
			trackinglist[top].setPhoneNumber(input.next());
			top++;
			input.close();
		}
		
		
		//WE NEED to use the AND operater because people may have the same first and last names
		public void Edit(PhoneBookEntry A) {
			Scanner input = new Scanner(System.in);
			int Edit_option;
			for(int k = 0; k < trackinglist.length; k++) {
				if(trackinglist[k].getFirstName().equals(A.getFirstName()) && trackinglist[k].getLastName().equals(A.getLastName())) {
					System.out.println("What would you like to edit");
					System.out.println("1.Id, \n  2.First Name, \n 3. Last Name,\n 4. Email,\n 5. Zipcode,\n 6.PhoneNumber");
					Edit_option = input.nextInt();
					switch(Edit_option) {
					case 1:
						System.out.println("Enter a new ID");
						trackinglist[k].setID(input.nextInt());
						break;
					case 2: 
						System.out.println("Enter a new first name");
						trackinglist[k].setFirstName(input.next());
						break;
					case 3:
						System.out.println("Enter a new Last Name");
						trackinglist[k].setLastName(input.next());
						break;
					case 4:
						System.out.println("Enter a new email");
						trackinglist[k].setEmail(input.next());
						break;
					case 5:
						System.out.println("Enter a new Zipcode");
						trackinglist[k].setZipCode(input.next());
						break;
					case 6:
						System.out.println("Enter a new PhoneNumber");
						trackinglist[k].setPhoneNumber(input.next());
						break;
					default:
						break;
						
					}
				}
			}
			//do not neccesarily need to close the Scanner;
			input.close();				
		}

		@Override
		//WE NEED to use the AND operater because people may have the same first and last names
	public int Delete(PhoneBookEntry B) {
			Scanner input = new Scanner(System.in);
			for(int k = 0; k < trackinglist.length; k++) {
				if(trackinglist[k].getFirstName().equals(B.getFirstName()) && trackinglist[k].getLastName().equals(B.getLastName())) {
					trackinglist[k].setID(0);
					trackinglist[k].setFirstName("");
					trackinglist[k].setLastName("");
					trackinglist[k].setEmail("");
					trackinglist[k].setZipCode("");
					trackinglist[k].setPhoneNumber("");
					top--;
					//
					Shift();
					//this is within my IF statement, so will return 1 only if value holds true.
					return 1;
				}
				
			// TODO Auto-generated method stub

		}
			//return 0, if nothing matches, yes spelling counts
			input.close();
			return 0;
	}
	public void Shift() {
		//Now we need to shift everything up and consolidate it;
		PhoneBookEntry temp;
		for (int i = 0; i < trackinglist.length; i++) {
			if (trackinglist[i].getID() == 0) {
				temp = trackinglist[i];
				for (int j = i+1; j < trackinglist.length; j++) {
					trackinglist[j-1] = trackinglist[j];
				}
				trackinglist[trackinglist.length-1] = temp;
			}
			
		}
	}


		//This sorts all my contact entries by ID number
		public void Sorter(PhoneBookEntry[] trackinglist2) {
			PhoneBookEntry [] temp_arr = trackinglist2;
			for(int i =0 ; i < temp_arr.length; i++) {
				PhoneBookEntry temp = temp_arr[i+1];
				if(temp_arr[i].getID() > temp_arr[i+1].getID()) {
					temp_arr[i+1] = temp_arr[i];
					temp_arr[i] = (User) temp;
				}
			}
			

			// TODO Auto-generated method stub

		}

		//My search by String by binary with our ID
		public int SearchByID(int id) {
			for(int k = 0; k <trackinglist.length; k++) {
				if(id == (trackinglist[k].getID())) {
					return 1;
				}
			}
			return 0;

		}

		//Searching by phonenumber which is a string
		//This is linear searching
		public int SearchByNumber(String n) {
			for(int j= 0; j< trackinglist.length; j++) {
				if(n.equals(trackinglist[j].getPhoneNumber())){
					trackinglist[j].PrintEntryInfo();
					return 1;
				}
			}
		
			return 0;
		}

		
		//You need both the password and username variables in order to display this.
		public void Display() {	
			System.out.println(Password);
			System.out.println(Username);
			System.out.println(Email);
		}

		
		public void ChangePassword(String p) {
			this.Password = p;
			
		}

		public void ChangeUsername(String u) {
			this.Username = u;

		}

		@Override
		public void Sorter(PhoneBookApp C) {
			// TODO Auto-generated method stub
			
		}
}
		