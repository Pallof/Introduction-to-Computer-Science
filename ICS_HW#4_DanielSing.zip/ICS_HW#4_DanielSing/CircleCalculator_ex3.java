// Calculate the area of a circle given the radius 
// Using a method that draws the input


import java.util.Scanner;

public class CircleCalculator_ex3{
	// setting the value of PI to a variable, less confusion
	public static double PI = 3.1415;
	public static void main(String[] args){

		
		Scanner input = new Scanner(System.in);

		System.out.println("Please input desired radius");
		// Defining what value of radius I want
		int radius = input.nextInt();
		System.out.println("The area of your circle is " + Value(radius));
		// Making sure to close my scanner
		input.close();
	}

	public static double Value(double rad){
		//doing my calculations to find circle value
		double area = PI * rad * rad;
		//Making sure to return my values
		return area;

	}
}