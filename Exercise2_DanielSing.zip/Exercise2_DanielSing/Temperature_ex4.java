// Farenheit to Celsius

import java.util.Scanner;

public class Temperature_ex4 {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);

		double conversion;
		System.out.println("Please enter the temperature in Farenheit");
		double farenheit = input.nextDouble();

		conversion = (5.0/9.0) * (farenheit - 32);

		System.out.println(farenheit + " Degrees farenheit converted to celsius is " + conversion + " Degrees Celsius");


		input.close();

	}
}