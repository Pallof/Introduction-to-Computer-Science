//Create a stack data structure that we can push and pop
// will neeed both a push method and a pop method
//(LIFO) structure ==> Last in first out data structure


import java.util.Scanner;

public class Lifo_ex4{
	
	//my global array, setting it at 100, should be plenty of room
	public static char [] myArray = new char [100];
	//im setting this to -1, so that in my +1 function 
	public static int top = -1;

	public static void main(String[] args){
		//call my methods here
		push('A');
		push('B');
		push('C');
		push('D');
		pop();
		pop();
		pop();
		pop();
	}

	public static void push(char c){ 
		//Scanner input = new Scanner(System.in);
		//System.out.println("Please enter a Character into an array");
		//char newLetter = input.next().charAt(0);
		//setting the new value as the next indice and setting my variable 'TOP' as the most recent indice
		//This will follow my last in first out principle
		myArray[top + 1] = c;
		top += 1;


	}
	// print the letter at the top of my stack
	//then remove it by 
	public static void pop(){
		//if the list is empty, then there shouldnt be anything to pop
		if(top == -1){
			System.out.println("No values to pop");

		}
		//Printing out my returned value and decreasing my 'top' value, so i dont need to remove it
		System.out.println(myArray[top]);
		top --;


	}

}