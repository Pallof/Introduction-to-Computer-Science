
import java.util.Scanner;


//Not sure if I need this class, because my interface and subclass take care of all my methods
public class PhoneBookApp {
	int top = 0;
	//1 new user
	User newUser = new User();
	//1 Admin
	Admin newAdmin = new Admin();
	//6 contacts 
	PhoneBookEntry trackinglist[] = new PhoneBookEntry[6];
	//My display all function
	public void Display() {
		for(int i = 0; i < trackinglist.length; i++) {
			trackinglist[i].PrintEntryInfo();
		}
	}
	
	public void Add() {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter ID");
		trackinglist[top].setID(input.nextInt());
		System.out.println("Please enter First name");
		trackinglist[top].setFirstName(input.next());
		System.out.println("Please enter last name");
		trackinglist[top].setLastName(input.next());
		System.out.println("Please enter email Address");
		trackinglist[top].setEmail(input.next());
		System.out.println("Please enter Zipcode");
		trackinglist[top].setZipCode(input.next());
		System.out.println("Please enter phone number");
		trackinglist[top].setPhoneNumber(input.next());
		top++;
		
		input.close();
		
	}
	
	public void Edit(String Fname, String Lname) {
		Scanner input = new Scanner(System.in);
		int Edit_option;
		for(int k = 0; k < trackinglist.length; k++) {
			if(trackinglist[k].getFirstName().equals(Fname) || trackinglist[k].getLastName().equals(Lname)) {
				System.out.println("What would you like to edit");
				System.out.println("1.Id, \n  2.First Name, \n 3. Last Name,\n 4. Email,\n 5. Zipcode,\n 6.PhoneNumber");
				Edit_option = input.nextInt();
				switch(Edit_option) {
				case 1:
					System.out.println("Enter a new ID");
					trackinglist[k].setID(input.nextInt());
					break;
				case 2: 
					System.out.println("Enter a new first name");
					trackinglist[k].setFirstName(input.next());
					break;
				case 3:
					System.out.println("Enter a new Last Name");
					trackinglist[k].setLastName(input.next());
					break;
				case 4:
					System.out.println("Enter a new email");
					trackinglist[k].setEmail(input.next());
					break;
				case 5:
					System.out.println("Enter a new Zipcode");
					trackinglist[k].setZipCode(input.next());
					break;
				case 6:
					System.out.println("Enter a new PhoneNumber");
					trackinglist[k].setPhoneNumber(input.next());
					break;
				default:
					break;
					
				}
				
			}
		}
		input.close();
		
	}
	
	//Change to return method
	public void SearchByNumber(String num) {
		for(int j= 0; j< trackinglist.length; j++) {
			if(num.equals(trackinglist[j].getPhoneNumber())){
				trackinglist[j].PrintEntryInfo();
			}
		}
	}
	//Change these to return methods, Binary Searching
	public void SearchByID(int ID) {
		for(int k = 0; k <trackinglist.length; k++) {
			if(ID == (trackinglist[k].getID())) {
				trackinglist[k].PrintEntryInfo();
				
				
			}
		}
	}
	// empty spaces and -1 will be defaults values;
	public int Delete(int ID) {
		for(int d = 0; d < trackinglist.length; d++) {
			if(trackinglist[d].getID() == ID) {
				trackinglist[d].setID(-1);
				trackinglist[d].setFirstName("");
				trackinglist[d].setLastName("");
				trackinglist[d].setEmail("");
				trackinglist[d].setZipCode("");
				trackinglist[d].setPhoneNumber(""); 
				return 1;
			}

			// Use this within the delete method to shift everything up
//			public int[] consolidateArray() {
//				for (int i = 0; i < arr.length; i++) {
//					if (arr[i] == 0) {
//						for (int j = i+1; j < arr.length; j++) {
//							arr[j-1] = arr[j];
//						}
//						arr[arr.length-1] = 0;
//					}
//					}
//				return arr;
//				}
		}
		return 0;
	}
	//Sorter method, learn selection sort/ Comparison in 13.6
	//sort by ID
	public int Sorter(int list []) {
		//temporary return
		return top;
		
	}

		
}

