//Homework #5, exercise 2
//Program that reads ints between 1 and 100 and counts the occurences of each
//https://stackoverflow.com/questions/42826762/program-that-reads-integers-between-1-and-100-and-counts-the-occurrence-of-each
//I used that link above to help me get started on this homework and wanted to give credit to the psoter
//I DID NOT copy the code, but i definitely used some of their ideas and implemented it into my code

import java.util.Scanner;

public class Overall_counter_ex2{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		int [] trackinglist = new int[100];

		//setting my values for the uniques
		// for(int i = 0, i<= trackinglist.legnth; i++){
		// 	trackinglist[i] = i;

		int count = 0;
		int insertion;
		System.out.println("Please enter values of 1-100 into the Array");
		//We need a do while here bc we have to test whether the first value enterted will be a zero or not
		//if it isnt then we can continue going
		do{
			insertion = input.nextInt();
			if(insertion < 0 || insertion >100){
				continue;
			}

			trackinglist[count] = insertion;
			count ++;

		}
		while(insertion != 0);
		System.out.println();
		Occurences(trackinglist);
		
		input.close();
	}



	public static void Occurences(int [] values){

		int uniquecounter = 0;
		for(int i = 1; i <= 100; i++ ){

			for(int j = 0; j<= values.length - 1; j++){

				if(values[j] == i){
					//set my values to negative 1 so i dont double count
					//values[j] = -1;
					uniquecounter +=1;
					}	
				}
			//Reset my counter everytime
			if(uniquecounter > 0){
				System.out.println(i + " Occurs " + uniquecounter + " times");
				uniquecounter = 0;
				}

			}
		//Something something 2 for loops
		}


}
