// Grade Calculator

import java.util.Scanner;

public class GradeCalculator_ex3 {
	public static void main(String[] args){ 
		Scanner input = new Scanner(System.in);
		double score;

		System.out.println("Please Enter Your Desired Grade");
		String grade = input.next();

		System.out.println("Enter minimum average required");
		double minAverage = input.nextDouble();

		System.out.println("Enter current average in course");
		double currentAverage = input.nextDouble();

		System.out.println("Enter How much final count as a percentage of the course grade");
		double test = input.nextDouble();
		test *= .01;
		score = ((minAverage - (currentAverage * (1 - test))) / test);
		System.out.println(score);

		input.close();
	}
}