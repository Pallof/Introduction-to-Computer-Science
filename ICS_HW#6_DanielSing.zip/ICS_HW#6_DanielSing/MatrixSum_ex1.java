//creating columns and rows in java, aka matrices
//creating a 4x4 matrix
//return the sum of a each colum
//Hw#6, Ex1

import java.util.Scanner;

public class MatrixSum_ex1{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	double [][] myMatrix = new double [4][4];

	//We need to fill in the numbers
	System.out.println("Enter a 4x4 matrix row by row");
	for(int col = 0; col < myMatrix.length ; col ++){

		for(int row = 0; row < myMatrix.length; row ++){

			myMatrix[col][row] = input.nextDouble();
		}
	}
	//Call method
	System.out.println();
	ColumnSum(myMatrix);
	//make sure to close my inputs.
	input.close();

//Close main
}

	//my summation method
	public static void ColumnSum(double [][] m){

	double sum = 0;
	//loop through the indices of each row and column
	for(int col = 0; col < m.length ; col ++){

		for(int row = 0; row < m.length; row ++){

			//the wording here is a little bit off, it should be switched?
			sum += m[row][col];

		}
		System.out.println("The sum of the elements at Column " + col + " is " + sum);

		//reset the sum
		sum = 0;
	}



	}
//Close the whole program
}