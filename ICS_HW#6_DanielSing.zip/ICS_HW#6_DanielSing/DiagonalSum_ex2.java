//Now we are doing diagonal matrix addition
//We should continue to use our for loops and go at a +1 rate, nvm this is wrong
//I only need to use one for loop
//for any n by n matrice as stated in the Homework


import java.util.Scanner;

public class DiagonalSum_ex2{
	public static void main(String[] args){


		Scanner input = new Scanner(System.in);

		System.out.println("Enter the size of your n by n matrix 'note n =n' so square matrix:" );
		int size = input.nextInt();

		double [][] myMatrix = new double[size][size];

		System.out.println("Enter a " + size + " by " + size + " matrix row by row");

		for(int col = 0; col < myMatrix.length; col++){
			for(int row = 0; row < myMatrix.length; row++){

				myMatrix[col][row] = input.nextDouble();
			}
		}
		System.out.println();
		System.out.println("The Sum of the elements in the major diagonal is " + Diagonals(myMatrix) + "\n");


		//call my method somewhere along here

		input.close();

	}

	//For reference the major diagonal is the diagonal that starts at the top left and ends at the bottom right
	//It is not the diagonal with the largest sum

	public static double Diagonals(double [][] m){

		double sum = 0;

		for(int row = 0; row < m.length; row++){
			//we want just the same number every time
			sum += m[row][row];
		}
		return sum;
		//returning my overall value
		//originally i was thinking of two forloops, but thats only for column addition
	}

}

