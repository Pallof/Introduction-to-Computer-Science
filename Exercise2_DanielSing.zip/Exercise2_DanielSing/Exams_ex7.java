//Calculate the arithmetic mean of your grades from the first three exams

import java.util.Scanner;
import java.text.DecimalFormat;
//I learned about this java import from Stack overflow
//I didn't have the book on me at the time, however I have commented in how to
// do it if I dont use the import method

public class Exams_ex7{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);

		System.out.println("Please enter your grades from the first three exams");
		double mean;
		double x1 = input.nextDouble();
		double x2 = input.nextDouble();
		double x3 = input.nextDouble();

		mean = (x1 + x2 + x3)/ (3.0);

		DecimalFormat f = new DecimalFormat("0.00");

		System.out.println("Input:\t\tOutput: ");
		System.out.print(x1 + " " + x2 + " " + x3);
		// I am printing Doubles because to accomodate if someone enters in double/float values
		//Also I have written below how to do formatting without import.	
		System.out.print("\t" + f.format(mean) + "\n");
		//System.out.printf("%.2f",mean);
		

		input.close();

	}
}