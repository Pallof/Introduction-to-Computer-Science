// Generate a random number between 1-10


public class RandomNumber_ex8 {
	public static void main(String[] args) {
		// multiply a value between 0 - 1 and multiply by 10 converted to int
	int random = (int)(Math.random()*10);

	System.out.println("Your random number between 1-10 is: " + random);


	}
}