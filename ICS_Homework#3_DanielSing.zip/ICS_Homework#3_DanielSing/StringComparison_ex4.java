//String Comparison
//Comparing the longest prefix

import java.util.Scanner;

public class StringComparison_ex4{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.println("Please Enter your first line");
	String stringone = input.nextLine();

	System.out.println("Please Enter your second line");
	String stringtwo = input.nextLine();


	int index = 0;
	//empty string to append letter to
	String similarity = "";
	// Comparing the two strings using a for loop
	// This will check from the beginning 
	while (stringone.charAt(index) == stringtwo.charAt(index)){
		similarity += stringone.charAt(index);
		index += 1;
		// This is to make sure no out of range index,
		// Did not realize that I had to test for this
		if (stringone.length() == index || stringtwo.length() == index){
			break;
		}
	}
	if (stringone.charAt(0) != stringtwo.charAt(0)){
		System.out.println(stringone + " and " + stringtwo + " have no common prefix");
	}
	else{
		// Using boolean to test, and to time when to print the correct statement
		// If While loop is false, then it will go straight to this if statement
		//If not, will eventually hit this boolean
		System.out.println("The common prefix is: " + similarity);
	}

	input.close();


		
	}
}

