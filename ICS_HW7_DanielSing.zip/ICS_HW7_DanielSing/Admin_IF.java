
public interface Admin_IF {
//	Add a phone entry
//	▪ Edit a phone entry of a given first name and last name
//	▪ Delete a phone entry of a given first name and last name
//	▪ Sort the PhoneBookDirectory
//	▪ Search using Linear Search
//	▪ Search using Binary Search
//	▪ Print Admin’s info
//	▪ Change Password
//	▪ Change Username
	public void Admin_menu();
	public void Add();
	//edit has yet to be coded;
	public void Edit(PhoneBookEntry A);
	public int Delete(PhoneBookEntry B);
	
	//This will be my consolidation Method, Where after we delete a value everything below it will be shifted up
	public void Shift();
	
	public void Sorter(PhoneBookApp C);
	
	public int SearchByID(int id);
	
	public int SearchByNumber(String n);
	
	public void Display();
	//this method has not yet been written
	public void ChangePassword(String p);
	//neither has this one
	public void ChangeUsername(String u);
}
