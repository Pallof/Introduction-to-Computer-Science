// Last digit of the sum of two given integers

import java.util.Scanner;

public class LastDigitSum_ex2{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter your first number");
		int first = input.nextInt();

		System.out.println("Please enter your second number");
		int second = input.nextInt();
		// Calling my main method
		System.out.println("The last digit of the sum of the two number's is: ");
		// Calling my method
		System.out.println(sumRemainder(first, second));
		// Closing my scanner
		input.close();

	}

	public static int sumRemainder(int x, int y){
		// add the two numbers first
		// then module by 10, and you will get the last digit
		int sum = x + y;
		sum %= 10;
		// Gotta have that return function
		return sum;

		}
	

}
