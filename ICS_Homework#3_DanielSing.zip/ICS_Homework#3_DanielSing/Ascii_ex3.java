//Ascii Table conversion


public class Ascii_ex3{
	public static void main(String[] args){
//Using a Forloop to loop through all my values
	int c, counter;
	counter = 0;

// Casting with int and Char to convert to the ASCII table value,
//I have set up a counter to format it into rows of 5
	for (c = 65; c <= 126; c++ ){
		System.out.print((char)c + " ");
		counter += 1;
		if (counter % 5 == 0){
			System.out.println();
			}
// This last statement is just so it looks prettier at the end on my bashscript
//Function still runs smoothly with or without it
		if (counter == 62){
			System.out.println();
			}

		}
		
	}
}