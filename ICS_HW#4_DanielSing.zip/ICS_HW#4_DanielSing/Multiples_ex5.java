// Given two numbers, test if second number is a multiple of the first
//Logic: see if the second number module of first number is == 0


import java.util.Scanner;

public class Multiples_ex5{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter your first number");
		int first = input.nextInt();

		System.out.println("Please enter your second number");
		int second = input.nextInt();
		//Calling my method
		Tester(first,second);

		//making sure to close my scanner
		input.close();
	}
	//Testing to see if there are any remainders
	//If the number divides perfectly, then you know its a multiple
	public static void Tester(int x, int y){
		if(x % y == 0){
			System.out.println(y + " Is a multple of " + x);
		}
		//If it doesn't fit, then it is NOT a multiple.
		else{
			System.out.println(y + " Is NOT a multple of " + x);
		}
	}
}