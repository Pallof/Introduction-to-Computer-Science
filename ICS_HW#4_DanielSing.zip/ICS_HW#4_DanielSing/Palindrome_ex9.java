//Palindromes for words and checking to see if they match
// We can use a while loop and test if they match at reverse indices

// Turns out the word " a man a plan a canal panama" is a palindrome
import java.util.Scanner;

public class Palindrome_ex9{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter a word to test if its a palindrome");
		String first = input.nextLine();
		// Stripping all the spaces, because we dont account for spaces in palindromes
		String fixed = first.replaceAll("\\s+" , "");

		//calling my method
		System.out.println(Testing(fixed));
	}

	public static Boolean Testing(String p){

		//Set my test varaible to length of string and navigate by indices
		int base = 0;
		int testcase = p.length()-1;

		while(testcase > base){
			//If at anypoint they dont match, then we return false
			if(p.charAt(testcase) != p.charAt(base)){
				return false;
			}
			//Base +1 each time because we start from 0
			// Testcase -1 each time
			//Both variables will eventually meet, and if at one point they dont match then not a palindrom
			base ++;
			testcase --;

		}
		//Only if all cases are TRUE
		return true;
	}



}


