
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PhoneBookMain {
	public static void main(String[] args) {
		Admin newAdmin = new Admin("Admin", "Password", "Admin@gmail.com");
		User newUser = new User(1234, "User", "Password");
		
		File newfile = new File("Admin.txt");
		File newfile2 = new File("User.txt");
		
		Scanner input = new Scanner(System.in);
		//TRY CATCH WITH ADMIN FILE
		try {
			Scanner filereader1 = new Scanner(new File("Admin.txt"));
			filereader1.useDelimiter(",");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//TRY CATCH WITH USER FILE
		try {
			
			Scanner filereader2 = new Scanner(new File("User.txt"));
			filereader2.useDelimiter(",");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("Please enter your login creditials");
		
		System.out.println("Enter Username");
		String User_input = input.next();
		System.out.println("Enter Passwrd");
		String Pass_input = input.next();
		
		int Admin_option;
		int User_option;
		
		if(User_input.equals(newAdmin.getUsername()) && Pass_input.equals(newAdmin.getPassword())) {
			
			do {
				System.out.println("Please enter what you would like to do as the Admin, please enter choice");
				newAdmin.Admin_menu();
				Admin_option = input.nextInt();
				switch(Admin_option) {
				
				case 1: 
					newAdmin.Add();
					break;
				case 2:
					newAdmin.Edit(newAdmin);
					break;
				case 3:
					newAdmin.Delete(newAdmin);
					break;
				case 4:
					newAdmin.Sorter(newAdmin.trackinglist);
					break;
				case 5: 
					System.out.println("please enter a phone number (String)");
					newAdmin.SearchByNumber(input.next());
					break;
				case 6:
					System.out.println("Please enter a Id Number");
					newAdmin.SearchByID(input.nextInt());
				case 7:
					newAdmin.Display();
					break;
				case 8:
					System.out.println("Please enter a new password");
					newAdmin.setPassword(input.next());
					break;
				case 9:
					System.out.println("Please enter a new Username");
					newAdmin.setUsername(input.next());
					break;
				default:
					System.out.println("No such option exists");
					break;
					
					
				}
				
				
			}
			while(Admin_option!= 10);
			
		}
		
		else if(User_input.equals(newUser.getUsername()) && Pass_input.equals(newUser.getPassword())) {
//			▪ Add a phone entry
//			▪ Edit a phone entry of a given first name and last name
//			▪ Sort the PhoneBookDirectory
//			▪ Search using Linear Search
//			▪ Print user’s info
			do {
				System.out.println("What would you like to do as the User, please enter choice");
				newUser.User_menu();
				User_option = input.nextInt();
				switch(User_option) {
				
				case 1:
					newUser.Add();
					break;
				case 2:
					System.out.println("Please enter the first and last name of given contact you would like to edit");
					newUser.Edit(newUser);
					break;
				case 3:
					newUser.Sorter(newUser.trackinglist);
					break;
				case 4:
					System.out.println("Please enter the phone number you would like to search");
					newUser.SearchByNumber(input.next());
					break;
				case 5:
					newUser.Display();
					break;
				default:
					System.out.println("no such option exists, please follow menu");
					break;
				}

			}
			while(User_option != 6);
		}
		
		else {
			System.out.println("Your username and password entereted does not exist in our database");
		}
		
		
	}
}
