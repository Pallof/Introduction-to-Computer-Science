//Conversion part 2, now we do it without the .toBinaryString()
//First we must figure out how to decipher a binary

import java.util.Scanner;

public class Conversion_part2_ex5{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter the number you would like to convert");
		int decimal = input.nextInt();
		// Need a empty string to keep track of all my value
		//Turns out we need to reverse it later
		String tracker = "";
		//Using a while loop to keep it running until decimal = 0

		while(decimal > 0){
			if(decimal % 2 == 0){
				tracker += "0" ;
				decimal /= 2;
			//Keep Dividing decimal by 2 after each iteration
				}
			else if(decimal % 2 == 1){
			
				tracker += "1";
				decimal /= 2;
				}
			} 
		// Reversing a string using a for loop
		// Start the loop at length minus becase of how indexes work
		for(int i = tracker.length()-1; i >=0 ; i --){
			System.out.print(tracker.charAt(i));
		}
		//Just so the console looks a little bit nicer
		System.out.println("\n");
	}
}