

public interface User_IF {	
	
	public void User_menu();
	public void Add();
	//edit has not been coded yet :(
	public void Edit(PhoneBookEntry d);
	public void Sorter(PhoneBookApp p);
	public void SearchByNumber(String num);
	public void Display();
}
