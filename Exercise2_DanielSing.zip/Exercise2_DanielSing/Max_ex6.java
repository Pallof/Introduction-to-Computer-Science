// Calculate the max given 2 number

import java.util.Scanner;
import java.lang.Math;

public class Max_ex6 {
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter two numbers to find out which one is larger");
		// Input for my values
		double x = input.nextDouble();
		double y = input.nextDouble();
		double max;
		//Comparing the two numbers to see which one is larger
		if (x>y)
			System.out.println("Your max value is " + x);
		else if (y>x) 
			System.out.println("Your max value is " + y);
		else 
			System.out.println("The two values you entered are identical");
		input.close();
	}	
}