//Calculator with integers

import java.util.Scanner;

public class calculator_ex1

{
	public static void main(String[] args)
	{
	Scanner input = new Scanner(System.in);
	int x,y,a,b,c,r;
	double d;
	System.out.println("Please enter x");
	x = input.nextInt();
	System.out.println("Please enter y");
	y = input.nextInt();

	a = x + y;
	b = x-y;
	c = x*y;
	r = x%y;
	d = (double)(x/y);



	System.out.println("Addition: "+ a);
	System.out.println("Subtraction: " + b);
	System.out.println("Multiplication: " + c);
	System.out.println("Division: " + d + "  Remainder: " + r);


	input.close();
	}
}