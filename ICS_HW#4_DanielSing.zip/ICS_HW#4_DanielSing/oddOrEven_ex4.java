// Odd or even
// See whether a number input is odd or even
// Our two exceptions are 1 and 0


import java.util.Scanner;

public class oddOrEven_ex4 {
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		//Main method where i will call my void method
		System.out.println("Please enter your desired number");
		int number = input.nextInt();
		Testcase(number);

	}
	public static void Testcase(int value){
		// need to exclude 1 and 0
		// we do this so we dont run into any external errors
		if (value == 1 || value == 0){
			System.out.println("1 and 0 are special cases and we will not classify them");
			}
		//Testing for even number
		else if(value % 2 == 0){
			System.out.println("Your number is even");
			}
		//testing for odd numbers
		else if(value % 2 == 1){
			System.out.println("Your number is odd");

		}
	}
}